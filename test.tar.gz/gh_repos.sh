cd repos
#git clone https://github.com/crystal-lang/crystal.git -b release/0.36
#git clone --depth 1 -b 1.9.0 https://github.com/crystal-lang/crystal
#git@github.com:crystal-lang/crystal.git --branch 1.6.2 --depth 1
#https://github.com/crystal-lang/crystal --branch 1.6.2 --depth 1
#Cписок репозиториев и тегов/веток к ним
#repo_addres1=https://github.com/crystal-lang/crystal.git
#nametag1=release/0.36
repo[0]=https://github.com/crystal-lang/crystal.git
repo[1]=https://github.com/docker/buildx.git
nt[0]=release/0.36
nt[1]=v0.19.1
repo_dir[0]=crytal
repo_dir[1]=buildx

cur=0
while [ $cur -lt 2 ]
do
	git clone --depth 1 ${repo[cur]} -b ${nt[cur]}
	#find . -name '*.tar.gz' | xargs -n1 echo
	find . -name '*.tar.gz' | xargs -n1 tar -xvf -C /$repo_dir[curr] 
	cur=$((cur+1))
done
#find . -name '*.tar.gz' | xargs -n1 tar -xvf

#Тест ручного ввода:
#read -p "Введите адрес репозитория:" repo_addres
#read -p "Введите номер тега/ветку репозитория:" nametage_or_branch_repo

